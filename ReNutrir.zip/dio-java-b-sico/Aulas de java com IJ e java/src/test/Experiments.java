package test;

import java.util.*;

public class Experiments {

    public static void main(String[] args) {

        Map <String, Livros> meusLivros = new TreeMap<>(){{

            put("Stephen Hawking", new Livros("Uma Breve História do Tempo", 256));
            put("Itamar Vieira Junior", new Livros("Zorto Arado", 100));
            put("Zilton Krenak", new Livros("Ideias para adiar o fim do mundo", 70));

        }};

        Set<Map.Entry<String, Livros>> livros = meusLivros.entrySet();

        for (Map.Entry <String, Livros> livro : livros) {

             System.out.println(livro.getKey() + "--" + livro.getValue().getPaginas());
        }

        Set <Map.Entry<String, Livros>> meusLivros2 = new TreeSet<>(new ComparatorNome());

        meusLivros2.addAll(meusLivros.entrySet());

        for (Map.Entry <String, Livros> livro : meusLivros2) {

            System.out.println(livro.getKey() + "--" + livro.getValue().getPaginas());
        }

    }
}

class Livros {

    private String nome;
    private Integer paginas;

    public Livros (String nome, Integer paginas) {
        this.nome = nome;
        this.paginas = paginas;
    }

    public String getNome() {
        return nome;
    }

    public Integer getPaginas() {
        return paginas;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livros livros = (Livros) o;
        return nome.equals(livros.nome) && paginas.equals(livros.paginas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, paginas);
    }

    @Override
    public String toString() {
        return "{" +
                "nome='" + nome + '\'' +
                ", paginas=" + paginas +
                '}';
    }
}

class ComparatorNome implements Comparator<Map.Entry<String, Livros>>{

    @Override
    public int compare(Map.Entry<String, Livros> l1, Map.Entry<String, Livros> l2) {
        return Integer.compare(l1.getValue().getPaginas(), l2.getValue().getPaginas());
    }
}

