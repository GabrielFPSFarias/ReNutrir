package test;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Math.sqrt;

public class Lista {

    public static void main(String[] args) {

        int pena = 4;

        List <Double> notas = new ArrayList <>(Arrays.asList(5d,6d,7d,8d));

        notas.add(7d);
        notas.add(8d);
        notas.add(9d);

        for (Double nota: notas) {
            System.out.println(nota);
        }

        double peso = sqrt(9);

        System.out.println(peso);

        switch (pena){

            case 1 :

                System.out.println("Yes");
                break;



        }
    }
}
