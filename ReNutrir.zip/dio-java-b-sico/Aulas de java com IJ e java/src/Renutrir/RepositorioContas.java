package Renutrir;

import java.util.ArrayList;

public class RepositorioContas {

   private ArrayList<Conta> contas;

   public void criarConta (String login, String senha, String nome, String telefone){

   }

   public void deletarConta (String nome){

   }

   public boolean buscarConta (String nome, Conta contas){

       return false;
   }

   public void atualizarConta (Conta conta) {

   }
}
