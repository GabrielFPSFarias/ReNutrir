package Renutrir;

public class Instituicao extends Conta{

    private String cnpj;
}
