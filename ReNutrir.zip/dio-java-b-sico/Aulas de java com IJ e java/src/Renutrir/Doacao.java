package Renutrir;

public class Doacao {

    private String tipoAlimento;
    private Doador doador;
    private Instituicao instituicao;
    private float quantidadeDoacao;
}

